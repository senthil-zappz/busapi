package com.javaproject.busapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusapiApplication.class, args);
	}

}
